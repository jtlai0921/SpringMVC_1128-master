package com.web.mvc.repository;

public interface WeatherDAO {
    String find(String cityName) throws Exception;
}
